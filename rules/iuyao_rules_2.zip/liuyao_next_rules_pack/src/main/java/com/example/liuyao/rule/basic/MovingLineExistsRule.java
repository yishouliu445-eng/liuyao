package com.example.liuyao.rule.basic;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;
import com.example.liuyao.rule.Rule;
import com.example.liuyao.rule.RuleHit;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 判断盘中是否存在动爻。
 * 这条规则本身不直接判断吉凶，只输出一个重要结构事实：
 * 当前是静卦还是动卦，以及哪些爻在动。
 */
@Component
public class MovingLineExistsRule implements Rule {

    @Override
    public RuleHit evaluate(ChartSnapshot chart) {
        RuleHit hit = new RuleHit();
        hit.setRuleCode("MOVING_LINE_EXISTS");
        hit.setRuleName("存在动爻");

        if (chart == null || chart.getLines() == null || chart.getLines().isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中没有可用爻信息。");
            hit.setEvidence(Map.of());
            return hit;
        }

        List<LineInfo> movingLines = chart.getLines().stream()
                .filter(line -> Boolean.TRUE.equals(line.getIsMoving()))
                .collect(Collectors.toList());

        if (movingLines.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前为静卦，无动爻。");
            hit.setEvidence(Map.of("movingLineCount", 0));
            return hit;
        }

        hit.setHit(true);
        hit.setImpactLevel("MEDIUM");
        hit.setHitReason("当前盘面存在动爻，后续需要结合变卦与动爻关系分析。");

        Map<String, Object> evidence = new HashMap<>();
        evidence.put("movingLineCount", movingLines.size());
        evidence.put("movingLineIndexes",
                movingLines.stream().map(LineInfo::getIndex).collect(Collectors.toList()));
        evidence.put("changeTargets",
                movingLines.stream().map(line -> Map.of(
                        "index", line.getIndex(),
                        "changeTo", line.getChangeTo() == null ? "" : line.getChangeTo()
                )).collect(Collectors.toList()));
        hit.setEvidence(evidence);
        return hit;
    }
}
