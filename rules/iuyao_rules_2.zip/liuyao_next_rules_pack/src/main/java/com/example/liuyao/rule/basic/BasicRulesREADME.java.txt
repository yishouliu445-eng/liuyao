说明：

1. MovingLineExistsRule
   - 用来判断是否有动爻
   - 输出动爻数量、动爻位置、变化目标
   - 不是直接判断吉凶，而是告诉系统“这是一个动卦”

2. ShiYingExistsRule
   - 用来做底座校验
   - 判断世爻、应爻是否都存在，且数量是否正常
   - 更像是排盘引擎的健康检查规则

接入方式：
- 把这两个类复制到你的 rule/basic 包
- 确保项目中的 LineInfo 有以下 getter：
  - getIndex()
  - getIsMoving()
  - getChangeTo()
  - getIsShi()
  - getIsYing()

如果你的字段名不同，改一下对应 getter 即可。
