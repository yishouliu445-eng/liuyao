package com.example.liuyao.rule.advanced;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;
import com.example.liuyao.rule.Rule;
import com.example.liuyao.rule.RuleHit;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 用神空亡规则（第一阶段简化版）。
 *
 * 使用前提：
 * 1. ChartSnapshot.ext 中已有 useGod（由 UseGodRule 或编排层写入）
 * 2. LineInfo 中存在 getLiuQin() 与 getBranch()
 * 3. ChartSnapshot 中存在 getKongWang()
 */
@Component
public class UseGodEmptyRule implements Rule {

    @Override
    public RuleHit evaluate(ChartSnapshot chart) {
        RuleHit hit = new RuleHit();
        hit.setRuleCode("USE_GOD_EMPTY");
        hit.setRuleName("用神逢空");

        if (chart == null || chart.getLines() == null || chart.getLines().isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中没有爻信息，无法判断用神空亡。");
            hit.setEvidence(Map.of());
            return hit;
        }

        String useGod = extractUseGod(chart);
        java.util.List<String> kongWang = chart.getKongWang();

        if (useGod == null || useGod.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供用神信息，无法判断是否空亡。");
            hit.setEvidence(Map.of());
            return hit;
        }

        if (kongWang == null || kongWang.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供空亡信息，无法判断用神是否落空。");
            hit.setEvidence(Map.of("useGod", useGod));
            return hit;
        }

        java.util.List<LineInfo> useGodLines = chart.getLines().stream()
                .filter(line -> useGod.equals(line.getLiuQin()))
                .collect(Collectors.toList());

        if (useGodLines.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中未找到对应的用神爻。");
            hit.setEvidence(Map.of(
                    "useGod", useGod,
                    "kongWang", kongWang
            ));
            return hit;
        }

        java.util.List<Map<String, Object>> emptyTargets = new ArrayList<>();
        for (LineInfo line : useGodLines) {
            String branch = line.getBranch();
            if (branch != null && kongWang.contains(branch)) {
                emptyTargets.add(Map.of(
                        "lineIndex", line.getIndex(),
                        "liuQin", line.getLiuQin(),
                        "branch", branch
                ));
            }
        }

        if (emptyTargets.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前用神未落空亡。");
            hit.setEvidence(Map.of(
                    "useGod", useGod,
                    "kongWang", kongWang
            ));
            return hit;
        }

        hit.setHit(true);
        hit.setImpactLevel("HIGH");
        hit.setHitReason("当前用神落空亡，后续应结合冲空、填实与动变继续分析。");
        hit.setEvidence(Map.of(
                "useGod", useGod,
                "kongWang", kongWang,
                "targets", emptyTargets
        ));
        return hit;
    }

    private String extractUseGod(ChartSnapshot chart) {
        if (chart.getExt() == null) {
            return null;
        }
        Object value = chart.getExt().get("useGod");
        return value == null ? null : String.valueOf(value);
    }
}
