package com.example.liuyao.rule.advanced;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;
import com.example.liuyao.rule.Rule;
import com.example.liuyao.rule.RuleHit;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * 世应关系规则（第一阶段简化版）。
 *
 * 当前版本只做“关系类型判定”，不直接判断吉凶：
 * - 世生应
 * - 应生世
 * - 世克应
 * - 应克世
 * - 世应比和
 *
 * 前提：
 * 1. LineInfo 中需要提供 getWuXing()
 * 2. 五行值建议为：金、木、水、火、土
 */
@Component
public class ShiYingRelationRule implements Rule {

    @Override
    public RuleHit evaluate(ChartSnapshot chart) {
        RuleHit hit = new RuleHit();
        hit.setRuleCode("SHI_YING_RELATION");
        hit.setRuleName("世应关系");

        if (chart == null || chart.getLines() == null || chart.getLines().isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中没有爻信息，无法分析世应关系。");
            hit.setEvidence(Map.of());
            return hit;
        }

        Optional<LineInfo> shiOpt = chart.getLines().stream()
                .filter(line -> Boolean.TRUE.equals(line.getIsShi()))
                .findFirst();

        Optional<LineInfo> yingOpt = chart.getLines().stream()
                .filter(line -> Boolean.TRUE.equals(line.getIsYing()))
                .findFirst();

        if (shiOpt.isEmpty() || yingOpt.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("世爻或应爻缺失，无法分析世应关系。");
            hit.setEvidence(Map.of(
                    "hasShi", shiOpt.isPresent(),
                    "hasYing", yingOpt.isPresent()
            ));
            return hit;
        }

        LineInfo shi = shiOpt.get();
        LineInfo ying = yingOpt.get();

        String shiWuXing = shi.getWuXing();
        String yingWuXing = ying.getWuXing();

        if (shiWuXing == null || yingWuXing == null || shiWuXing.isBlank() || yingWuXing.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("世应五行信息缺失，无法分析生克关系。");
            hit.setEvidence(Map.of(
                    "shiWuXing", shiWuXing,
                    "yingWuXing", yingWuXing
            ));
            return hit;
        }

        String relation = resolveRelation(shiWuXing, yingWuXing);

        Map<String, Object> evidence = new HashMap<>();
        evidence.put("shiIndex", shi.getIndex());
        evidence.put("yingIndex", ying.getIndex());
        evidence.put("shiWuXing", shiWuXing);
        evidence.put("yingWuXing", yingWuXing);
        evidence.put("relation", relation);

        hit.setHit(true);
        hit.setImpactLevel("MEDIUM");
        hit.setHitReason("已识别世应之间的五行关系，可供后续解释层使用。");
        hit.setEvidence(evidence);
        return hit;
    }

    private String resolveRelation(String shiWuXing, String yingWuXing) {
        if (shiWuXing.equals(yingWuXing)) {
            return "比和";
        }
        if (generates(shiWuXing, yingWuXing)) {
            return "世生应";
        }
        if (generates(yingWuXing, shiWuXing)) {
            return "应生世";
        }
        if (controls(shiWuXing, yingWuXing)) {
            return "世克应";
        }
        if (controls(yingWuXing, shiWuXing)) {
            return "应克世";
        }
        return "未知";
    }

    private boolean generates(String from, String to) {
        return ("木".equals(from) && "火".equals(to))
                || ("火".equals(from) && "土".equals(to))
                || ("土".equals(from) && "金".equals(to))
                || ("金".equals(from) && "水".equals(to))
                || ("水".equals(from) && "木".equals(to));
    }

    private boolean controls(String from, String to) {
        return ("木".equals(from) && "土".equals(to))
                || ("土".equals(from) && "水".equals(to))
                || ("水".equals(from) && "火".equals(to))
                || ("火".equals(from) && "金".equals(to))
                || ("金".equals(from) && "木".equals(to));
    }
}
