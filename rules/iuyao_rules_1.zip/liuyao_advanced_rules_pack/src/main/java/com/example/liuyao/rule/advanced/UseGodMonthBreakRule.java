package com.example.liuyao.rule.advanced;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;
import com.example.liuyao.rule.Rule;
import com.example.liuyao.rule.RuleHit;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 用神月破规则（第一阶段简化版）。
 *
 * 简化口径：
 * - 以“月建地支”与“用神所在爻地支”是否相冲来判定月破
 *
 * 使用前提：
 * 1. ChartSnapshot.ext 中存在 useGod
 * 2. ChartSnapshot.getYueJian() 返回月建地支（如 子 / 丑 / 寅 ...）
 * 3. LineInfo.getBranch() 返回爻支
 */
@Component
public class UseGodMonthBreakRule implements Rule {

    @Override
    public RuleHit evaluate(ChartSnapshot chart) {
        RuleHit hit = new RuleHit();
        hit.setRuleCode("USE_GOD_MONTH_BREAK");
        hit.setRuleName("用神月破");

        if (chart == null || chart.getLines() == null || chart.getLines().isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中没有爻信息，无法判断月破。");
            hit.setEvidence(Map.of());
            return hit;
        }

        String useGod = extractUseGod(chart);
        String yueJian = chart.getYueJian();

        if (useGod == null || useGod.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供用神信息，无法判断月破。");
            hit.setEvidence(Map.of());
            return hit;
        }

        if (yueJian == null || yueJian.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供月建信息，无法判断月破。");
            hit.setEvidence(Map.of("useGod", useGod));
            return hit;
        }

        java.util.List<LineInfo> useGodLines = chart.getLines().stream()
                .filter(line -> useGod.equals(line.getLiuQin()))
                .collect(Collectors.toList());

        if (useGodLines.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中未找到对应的用神爻。");
            hit.setEvidence(Map.of(
                    "useGod", useGod,
                    "yueJian", yueJian
            ));
            return hit;
        }

        java.util.List<Map<String, Object>> brokenTargets = new ArrayList<>();
        for (LineInfo line : useGodLines) {
            String branch = line.getBranch();
            if (branch != null && isChong(yueJian, branch)) {
                brokenTargets.add(Map.of(
                        "lineIndex", line.getIndex(),
                        "liuQin", line.getLiuQin(),
                        "branch", branch
                ));
            }
        }

        if (brokenTargets.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前用神未见月破。");
            hit.setEvidence(Map.of(
                    "useGod", useGod,
                    "yueJian", yueJian
            ));
            return hit;
        }

        hit.setHit(true);
        hit.setImpactLevel("HIGH");
        hit.setHitReason("当前用神受月建相冲，存在月破信号。");
        hit.setEvidence(Map.of(
                "useGod", useGod,
                "yueJian", yueJian,
                "targets", brokenTargets
        ));
        return hit;
    }

    private boolean isChong(String a, String b) {
        return ("子".equals(a) && "午".equals(b)) || ("午".equals(a) && "子".equals(b))
                || ("丑".equals(a) && "未".equals(b)) || ("未".equals(a) && "丑".equals(b))
                || ("寅".equals(a) && "申".equals(b)) || ("申".equals(a) && "寅".equals(b))
                || ("卯".equals(a) && "酉".equals(b)) || ("酉".equals(a) && "卯".equals(b))
                || ("辰".equals(a) && "戌".equals(b)) || ("戌".equals(a) && "辰".equals(b))
                || ("巳".equals(a) && "亥".equals(b)) || ("亥".equals(a) && "巳".equals(b));
    }

    private String extractUseGod(ChartSnapshot chart) {
        if (chart.getExt() == null) {
            return null;
        }
        Object value = chart.getExt().get("useGod");
        return value == null ? null : String.valueOf(value);
    }
}
