package com.example.liuyao.rule.batch;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 一个可选的小工具类。
 * 如果后面你发现很多规则都要先“找到用神爻”，可以统一复用这个工具。
 */
public final class UseGodLineLocator {

    private UseGodLineLocator() {}

    public static List<LineInfo> findUseGodLines(ChartSnapshot chart, String useGod) {
        if (chart == null || chart.getLines() == null || useGod == null || useGod.isBlank()) {
            return List.of();
        }
        return chart.getLines().stream()
                .filter(line -> useGod.equals(line.getLiuQin()))
                .collect(Collectors.toList());
    }
}
