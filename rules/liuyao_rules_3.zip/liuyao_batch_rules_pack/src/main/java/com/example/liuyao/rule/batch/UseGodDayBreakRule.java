package com.example.liuyao.rule.batch;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;
import com.example.liuyao.rule.Rule;
import com.example.liuyao.rule.RuleHit;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 用神日破规则（简化版）。
 *
 * 前提：
 * 1. chart.getRiChen() 返回日辰地支，例如：子、丑、寅...
 * 2. chart.getExt().get("useGod") 已写入当前用神（如 官鬼、妻财）
 * 3. LineInfo.getBranch() / getLiuQin() 可用
 */
@Component
public class UseGodDayBreakRule implements Rule {

    @Override
    public RuleHit evaluate(ChartSnapshot chart) {
        RuleHit hit = new RuleHit();
        hit.setRuleCode("USE_GOD_DAY_BREAK");
        hit.setRuleName("用神日破");

        if (chart == null || chart.getLines() == null || chart.getLines().isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中没有爻信息，无法判断日破。");
            hit.setEvidence(Map.of());
            return hit;
        }

        String useGod = extractUseGod(chart);
        String riChen = chart.getRiChen();

        if (useGod == null || useGod.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供用神信息，无法判断日破。");
            hit.setEvidence(Map.of());
            return hit;
        }

        if (riChen == null || riChen.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供日辰信息，无法判断日破。");
            hit.setEvidence(Map.of("useGod", useGod));
            return hit;
        }

        String riBranch = extractBranch(riChen);
        if (riBranch == null) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("无法从日辰中提取地支，无法判断日破。");
            hit.setEvidence(Map.of("riChen", riChen));
            return hit;
        }

        List<LineInfo> useGodLines = chart.getLines().stream()
                .filter(line -> useGod.equals(line.getLiuQin()))
                .collect(Collectors.toList());

        List<Map<String, Object>> brokenTargets = new ArrayList<>();
        for (LineInfo line : useGodLines) {
            if (line.getBranch() != null && isChong(riBranch, line.getBranch())) {
                brokenTargets.add(Map.of(
                        "lineIndex", line.getIndex(),
                        "liuQin", line.getLiuQin(),
                        "branch", line.getBranch()
                ));
            }
        }

        if (brokenTargets.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前用神未见日破。");
            hit.setEvidence(Map.of("useGod", useGod, "riChen", riChen, "riBranch", riBranch));
            return hit;
        }

        hit.setHit(true);
        hit.setImpactLevel("HIGH");
        hit.setHitReason("当前用神受日辰相冲，存在日破信号。");
        hit.setEvidence(Map.of(
                "useGod", useGod,
                "riChen", riChen,
                "riBranch", riBranch,
                "targets", brokenTargets
        ));
        return hit;
    }

    private String extractUseGod(ChartSnapshot chart) {
        if (chart.getExt() == null) return null;
        Object value = chart.getExt().get("useGod");
        return value == null ? null : String.valueOf(value);
    }

    private String extractBranch(String gz) {
        if (gz == null || gz.isBlank()) return null;
        String[] branches = {"子","丑","寅","卯","辰","巳","午","未","申","酉","戌","亥"};
        for (String b : branches) {
            if (gz.contains(b)) return b;
        }
        return null;
    }

    private boolean isChong(String a, String b) {
        return ("子".equals(a) && "午".equals(b)) || ("午".equals(a) && "子".equals(b))
                || ("丑".equals(a) && "未".equals(b)) || ("未".equals(a) && "丑".equals(b))
                || ("寅".equals(a) && "申".equals(b)) || ("申".equals(a) && "寅".equals(b))
                || ("卯".equals(a) && "酉".equals(b)) || ("酉".equals(a) && "卯".equals(b))
                || ("辰".equals(a) && "戌".equals(b)) || ("戌".equals(a) && "辰".equals(b))
                || ("巳".equals(a) && "亥".equals(b)) || ("亥".equals(a) && "巳".equals(b));
    }
}
