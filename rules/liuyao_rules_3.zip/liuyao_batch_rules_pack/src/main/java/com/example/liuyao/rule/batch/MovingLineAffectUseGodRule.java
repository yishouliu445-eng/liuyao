package com.example.liuyao.rule.batch;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;
import com.example.liuyao.rule.Rule;
import com.example.liuyao.rule.RuleHit;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 动爻是否影响用神（简化版）。
 *
 * 当前口径：
 * - 动爻若五行生用神 => "动爻生用神"
 * - 动爻若五行克用神 => "动爻克用神"
 * - 仅输出结构事实，不直接判吉凶
 *
 * 前提：
 * 1. chart.ext.useGod 已写入
 * 2. LineInfo.getWuXing() / getLiuQin() / getIsMoving() 可用
 */
@Component
public class MovingLineAffectUseGodRule implements Rule {

    @Override
    public RuleHit evaluate(ChartSnapshot chart) {
        RuleHit hit = new RuleHit();
        hit.setRuleCode("MOVING_LINE_AFFECT_USE_GOD");
        hit.setRuleName("动爻影响用神");

        if (chart == null || chart.getLines() == null || chart.getLines().isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中没有爻信息，无法判断动爻是否影响用神。");
            hit.setEvidence(Map.of());
            return hit;
        }

        String useGod = extractUseGod(chart);
        if (useGod == null || useGod.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供用神信息，无法判断动爻是否影响用神。");
            hit.setEvidence(Map.of());
            return hit;
        }

        List<LineInfo> useGodLines = chart.getLines().stream()
                .filter(line -> useGod.equals(line.getLiuQin()))
                .collect(Collectors.toList());

        if (useGodLines.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中未找到对应的用神爻。");
            hit.setEvidence(Map.of("useGod", useGod));
            return hit;
        }

        String useGodWuXing = useGodLines.get(0).getWuXing();
        if (useGodWuXing == null || useGodWuXing.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("用神五行缺失，无法判断动爻影响。");
            hit.setEvidence(Map.of("useGod", useGod));
            return hit;
        }

        List<LineInfo> movingLines = chart.getLines().stream()
                .filter(line -> Boolean.TRUE.equals(line.getIsMoving()))
                .collect(Collectors.toList());

        if (movingLines.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前无动爻，无法判断对用神的影响。");
            hit.setEvidence(Map.of("useGod", useGod));
            return hit;
        }

        List<Map<String, Object>> effects = new ArrayList<>();
        for (LineInfo moving : movingLines) {
            String movingWuXing = moving.getWuXing();
            if (movingWuXing == null || movingWuXing.isBlank()) continue;

            String relation = null;
            if (generates(movingWuXing, useGodWuXing)) {
                relation = "动爻生用神";
            } else if (controls(movingWuXing, useGodWuXing)) {
                relation = "动爻克用神";
            }

            if (relation != null) {
                effects.add(Map.of(
                        "lineIndex", moving.getIndex(),
                        "liuQin", moving.getLiuQin(),
                        "movingWuXing", movingWuXing,
                        "useGodWuXing", useGodWuXing,
                        "relation", relation
                ));
            }
        }

        if (effects.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前动爻对用神未形成明显生克。");
            hit.setEvidence(Map.of(
                    "useGod", useGod,
                    "useGodWuXing", useGodWuXing
            ));
            return hit;
        }

        hit.setHit(true);
        hit.setImpactLevel("MEDIUM");
        hit.setHitReason("已识别部分动爻对用神形成生克影响。");
        hit.setEvidence(Map.of(
                "useGod", useGod,
                "useGodWuXing", useGodWuXing,
                "effects", effects
        ));
        return hit;
    }

    private String extractUseGod(ChartSnapshot chart) {
        if (chart.getExt() == null) return null;
        Object value = chart.getExt().get("useGod");
        return value == null ? null : String.valueOf(value);
    }

    private boolean generates(String from, String to) {
        return ("木".equals(from) && "火".equals(to))
                || ("火".equals(from) && "土".equals(to))
                || ("土".equals(from) && "金".equals(to))
                || ("金".equals(from) && "水".equals(to))
                || ("水".equals(from) && "木".equals(to));
    }

    private boolean controls(String from, String to) {
        return ("木".equals(from) && "土".equals(to))
                || ("土".equals(from) && "水".equals(to))
                || ("水".equals(from) && "火".equals(to))
                || ("火".equals(from) && "金".equals(to))
                || ("金".equals(from) && "木".equals(to));
    }
}
