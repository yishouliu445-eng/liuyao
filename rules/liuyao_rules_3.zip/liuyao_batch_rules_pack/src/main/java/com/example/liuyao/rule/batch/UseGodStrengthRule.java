package com.example.liuyao.rule.batch;

import com.example.liuyao.divination.domain.ChartSnapshot;
import com.example.liuyao.divination.domain.LineInfo;
import com.example.liuyao.rule.Rule;
import com.example.liuyao.rule.RuleHit;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 用神强弱规则（第一阶段启发式简化版）。
 *
 * 当前并不是完整传统旺衰算法，只是做一个可落地的“结构化评分”：
 * +2 得月建五行生扶或同五行
 * +1 得日辰五行生扶或同五行
 * -2 月建克
 * -1 日辰克
 *
 * 最终输出：
 * - STRONG / MEDIUM / WEAK
 *
 * 前提：
 * 1. LineInfo.getWuXing() / getLiuQin() 可用
 * 2. chart.getYueJian() / getRiChen() 可提取到地支
 * 3. chart.ext.useGod 已写入
 */
@Component
public class UseGodStrengthRule implements Rule {

    @Override
    public RuleHit evaluate(ChartSnapshot chart) {
        RuleHit hit = new RuleHit();
        hit.setRuleCode("USE_GOD_STRENGTH");
        hit.setRuleName("用神强弱");

        if (chart == null || chart.getLines() == null || chart.getLines().isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中没有爻信息，无法判断用神强弱。");
            hit.setEvidence(Map.of());
            return hit;
        }

        String useGod = extractUseGod(chart);
        if (useGod == null || useGod.isBlank()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("当前盘面未提供用神信息，无法判断用神强弱。");
            hit.setEvidence(Map.of());
            return hit;
        }

        List<LineInfo> targets = chart.getLines().stream()
                .filter(line -> useGod.equals(line.getLiuQin()))
                .collect(Collectors.toList());

        if (targets.isEmpty()) {
            hit.setHit(false);
            hit.setImpactLevel("LOW");
            hit.setHitReason("盘面中未找到对应的用神爻。");
            hit.setEvidence(Map.of("useGod", useGod));
            return hit;
        }

        String yueBranch = extractBranch(chart.getYueJian());
        String riBranch = extractBranch(chart.getRiChen());
        String yueWuXing = branchToWuXing(yueBranch);
        String riWuXing = branchToWuXing(riBranch);

        List<Map<String, Object>> details = new ArrayList<>();
        int bestScore = Integer.MIN_VALUE;
        String bestLevel = "UNKNOWN";

        for (LineInfo line : targets) {
            String lineWuXing = line.getWuXing();
            int score = 0;

            if (lineWuXing != null && yueWuXing != null) {
                if (lineWuXing.equals(yueWuXing) || generates(yueWuXing, lineWuXing)) score += 2;
                if (controls(yueWuXing, lineWuXing)) score -= 2;
            }
            if (lineWuXing != null && riWuXing != null) {
                if (lineWuXing.equals(riWuXing) || generates(riWuXing, lineWuXing)) score += 1;
                if (controls(riWuXing, lineWuXing)) score -= 1;
            }

            String level = toLevel(score);
            if (score > bestScore) {
                bestScore = score;
                bestLevel = level;
            }

            details.add(Map.of(
                    "lineIndex", line.getIndex(),
                    "liuQin", line.getLiuQin(),
                    "wuXing", lineWuXing == null ? "" : lineWuXing,
                    "score", score,
                    "level", level
            ));
        }

        hit.setHit(true);
        hit.setImpactLevel("MEDIUM");
        hit.setHitReason("已按月建、日辰对用神做启发式强弱评估。");
        hit.setEvidence(Map.of(
                "useGod", useGod,
                "yueJian", chart.getYueJian(),
                "riChen", chart.getRiChen(),
                "bestScore", bestScore,
                "bestLevel", bestLevel,
                "details", details
        ));
        return hit;
    }

    private String extractUseGod(ChartSnapshot chart) {
        if (chart.getExt() == null) return null;
        Object value = chart.getExt().get("useGod");
        return value == null ? null : String.valueOf(value);
    }

    private String extractBranch(String source) {
        if (source == null || source.isBlank()) return null;
        String[] branches = {"子","丑","寅","卯","辰","巳","午","未","申","酉","戌","亥"};
        for (String b : branches) {
            if (source.contains(b)) return b;
        }
        return null;
    }

    private String branchToWuXing(String branch) {
        if (branch == null) return null;
        return switch (branch) {
            case "寅", "卯" -> "木";
            case "巳", "午" -> "火";
            case "辰", "戌", "丑", "未" -> "土";
            case "申", "酉" -> "金";
            case "亥", "子" -> "水";
            default -> null;
        };
    }

    private boolean generates(String from, String to) {
        return ("木".equals(from) && "火".equals(to))
                || ("火".equals(from) && "土".equals(to))
                || ("土".equals(from) && "金".equals(to))
                || ("金".equals(from) && "水".equals(to))
                || ("水".equals(from) && "木".equals(to));
    }

    private boolean controls(String from, String to) {
        return ("木".equals(from) && "土".equals(to))
                || ("土".equals(from) && "水".equals(to))
                || ("水".equals(from) && "火".equals(to))
                || ("火".equals(from) && "金".equals(to))
                || ("金".equals(from) && "木".equals(to));
    }

    private String toLevel(int score) {
        if (score >= 2) return "STRONG";
        if (score >= 0) return "MEDIUM";
        return "WEAK";
    }
}
